package com.example.rtx2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Binder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class VerificationViaEmail extends AppCompatActivity {

    RadioButton fake_radio_button;
    EditText fake_otp;
    Button fake_verify_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification_via_email);

        fake_radio_button = (RadioButton) findViewById(R.id.fake_radio_button);
        fake_otp = findViewById(R.id.fake_otp);
        fake_verify_button = findViewById(R.id.fake_verify_button);

        fake_radio_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fake_otp.setVisibility(View.VISIBLE);
                fake_verify_button.setVisibility(View.VISIBLE);
            }
        });

        fake_verify_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(fake_otp.getText().toString().equals("412973")){
                    Toast.makeText(getApplicationContext(), "Registered successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(".Login");
                    startActivity(intent);
                }
                else{
                    Toast.makeText(getApplicationContext(), "Wrong OTP", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}